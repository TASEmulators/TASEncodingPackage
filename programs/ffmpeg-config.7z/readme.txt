The versions of ffmpeg and ffprobe included in this package were custom built
using the excellent tool at: https://github.com/m-ab-s/media-autobuild_suite

Included in this archive are two sets of configuration files for the above tool
that will generate the ffmpeg and ffprobe executables. Once the media-autobuild
tool has been set-up and run once, either set of two files can be dropped into
the build folder, and the tool will generate the executable.